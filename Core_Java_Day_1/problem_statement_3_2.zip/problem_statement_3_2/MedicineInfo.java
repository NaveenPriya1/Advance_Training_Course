package problem_statement_3_2;

public interface MedicineInfo {
       void displayLabel();
}
