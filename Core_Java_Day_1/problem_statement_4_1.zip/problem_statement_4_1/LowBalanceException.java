package problem_statement_4_1;

public class LowBalanceException extends Exception{
  public String string() {
	  return "LowBalance";
  }
}
