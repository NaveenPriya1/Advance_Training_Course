package problem_statement_3_2;

public class Ointment implements MedicineInfo{

	@Override
	public void displayLabel() {
		System.out.println("for external use only");
		
	}

}
