package problem_statement_4_1;

public class NegitiveBalanceException extends Exception{
   public String string() {
	   return "Negitive balance";
   }
}
