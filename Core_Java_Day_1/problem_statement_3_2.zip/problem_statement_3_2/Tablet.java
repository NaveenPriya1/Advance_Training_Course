package problem_statement_3_2;

public class Tablet implements MedicineInfo{

	@Override
	public void displayLabel() {
		System.out.println("Store in a cool and dry place");
		
	}

}
