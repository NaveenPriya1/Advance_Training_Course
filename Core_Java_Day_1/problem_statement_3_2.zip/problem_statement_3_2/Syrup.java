package problem_statement_3_2;

public class Syrup implements MedicineInfo{

	@Override
	public void displayLabel() {
		System.out.println("Shake well before use");
		
	}

}
