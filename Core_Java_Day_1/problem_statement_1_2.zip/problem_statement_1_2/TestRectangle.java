package problem_statement_1_2;

//TestRectangle class
public  class TestRectangle{
	
 public static void main(String[] args) {
		Rectangle obj1 = new Rectangle();
		obj1.input();
		obj1.calArea();
		obj1.display();
		System.out.println("=============================");
		
		Rectangle obj2 = new Rectangle();
		obj2.input();
		obj2.calArea();
		obj2.display();
		System.out.println("=============================");
		
		Rectangle obj3 = new Rectangle();
		obj3.input();
		obj3.calArea();
		obj3.display();
		System.out.println("=============================");
		
		Rectangle obj4 = new Rectangle();
		obj4.input();
		obj4.calArea();
		obj4.display();
		System.out.println("=============================");
		
		Rectangle obj5 = new Rectangle();
		obj5.input();
		obj5.calArea();
		obj5.display();

	}

}