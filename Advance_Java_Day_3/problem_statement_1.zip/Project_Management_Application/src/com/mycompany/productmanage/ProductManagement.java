package com.mycompany.productmanage;

import com.mycompany.ui.ProductConsole;

public class ProductManagement {

    
    public static void main(String[] args) {
        ProductConsole pc = new ProductConsole();
        pc.start();
    }
    
}

