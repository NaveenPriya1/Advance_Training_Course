package problem_statement_4_1;

public class InsufficientFundsException extends Exception{
	
	public String toString() {
		
		return "InsufficientFunds";
	}

}
